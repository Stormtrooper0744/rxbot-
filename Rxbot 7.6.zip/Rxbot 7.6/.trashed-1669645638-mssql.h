#ifndef NO_MSSQL
BOOL MSSQL(EXINFO exinfo);
#endif