#ifndef NO_WILDCARD
int set(char **wildcard, char **test);
int asterisk(char **wildcard, char **test);
int wildcardfit(char *wildcard, char *test);
#endif
